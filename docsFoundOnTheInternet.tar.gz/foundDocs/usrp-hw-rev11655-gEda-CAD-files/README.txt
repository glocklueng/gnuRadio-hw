You need the gEda Electronic Design Automation CAD tools to open the design files.

You can find the gEda tools at:
http://www.gpleda.org/

The .sch files are schemtics, you can open them with gschem
The .pcb files are layout, you can open them with pcb

