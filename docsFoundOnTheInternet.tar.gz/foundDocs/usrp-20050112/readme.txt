USRP Files pack v. usrp-20050112
Here you'll find all the documentation and files for the USRP
repacked from _tar to .zip (http://www.ettus.com/Download.html)
==============================================================


Mboard - USRP Data
This file contains all schematics for the USRP motherboard. The schematics are in PS, PDF, and gSchem format. Netlists and command scripts are also included. Download usrp-mboard-20050112_tar.gz

Dboards - BasicRX and BasicTX Docs
This contains all schematics, scripts, netlists, and layout files for the BasicRX and BasicTX daughterboards. Download basic-dboard-20050112_tar.gz

Parts - Components
This contains PCB outlines and schematic parts for the above files. Download parts-20050112_tar.gz

